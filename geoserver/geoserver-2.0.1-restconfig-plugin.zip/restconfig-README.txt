GeoServer RESTful Configuration Extension
-----------------------------------------

See the user guide for information:

http://docs.geoserver.org/2.0.x/en/user/extensions/rest/index.html

